plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.dshm.calc"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.dshm.calc"
        minSdk = 23
        targetSdk = 37
        versionCode = 3
        versionName = "2.0-release"
    }

    // 如需给 release 签名：请自行生成 keystore，并通过 local.properties 或环境变量提供
    // 路径与密码（例如 storeFile / storePassword / keyAlias / keyPassword），
    // 切勿把 keystore 文件或密码提交到仓库。未配置时 assembleRelease 产出未签名 APK。
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += setOf(
                "DebugProbesKt.bin",
                "kotlin-tooling-metadata.json",
                "kotlin/**",
                "META-INF/*.version",
                "META-INF/**/LICENSE.txt"
            )
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.compose.foundation)
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.backdrop)
    implementation(libs.kyant.shapes)
}
