package com.dshm.calc

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.launch
import java.io.File
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CalculatorApp() }
    }
}

private val MC = MathContext(12, RoundingMode.HALF_UP)

private val DarkGradient = listOf(
    Color(0xFF16324F), Color(0xFF0A4D8C), Color(0xFF3A2E6E), Color(0xFF16324F)
)
private val LightGradient = listOf(
    Color(0xFFE6EEF8), Color(0xFFC7DBF2), Color(0xFFD9D0EC), Color(0xFFE6EEF8)
)

private fun isImage(file: File): Boolean {
    val n = file.name.lowercase()
    return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") ||
        n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".bmp") ||
        n.endsWith(".heic") || n.endsWith(".heif")
}

private fun decodeWallpaper(path: String): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var sample = 1
    val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
    while (maxDim / sample > 2048) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    BitmapFactory.decodeFile(path, opts)
} catch (e: Exception) { null }

private fun isWallpaperDark(bitmap: Bitmap): Boolean {
    val scaled = Bitmap.createScaledBitmap(bitmap, 32, 32, false)
    var sum = 0L
    val n = 32 * 32
    for (x in 0 until 32) {
        for (y in 0 until 32) {
            val p = scaled.getPixel(x, y)
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            sum += (0.299 * r + 0.587 * g + 0.114 * b).toLong()
        }
    }
    return (sum / n) < 128
}

val LocalVibrationLevel = compositionLocalOf { "standard" }

private fun hapticType(level: String, strong: Boolean): HapticFeedbackType? {
    return when (level) {
        "off" -> null
        "enhanced" -> if (Build.VERSION.SDK_INT >= 30) {
            if (strong) HapticFeedbackType.Reject else HapticFeedbackType.VirtualKey
        } else {
            if (strong) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
        }
        else -> if (strong) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
    }
}

enum class Lang(val code: String) { ZH_CN("zh-CN"), ZH_TW("zh-TW"), EN("en") }

data class Str(
    val title: String, val settings: String, val darkMode: String, val wallpaper: String,
    val vibration: String, val language: String, val about: String,
    val followSystem: String, val wallpaperColor: String, val none: String,
    val off: String, val standard: String, val enhanced: String, val cancel: String,
    val version: String, val ok: String, val permText: String, val grant: String,
    val restoreDefault: String, val close: String, val error: String, val copy: String
)

private val strings = mapOf(
    Lang.ZH_CN to Str(
        "计算器", "设置", "深色模式", "壁纸", "震动", "语言", "关于",
        "跟随系统", "壁纸取色", "无", "关闭", "标准", "增强", "取消",
        "版本 V2.0-release", "确定", "更换壁纸需要「允许访问所有文件」权限", "去授权", "恢复默认", "关闭", "错误", "复制"
    ),
    Lang.ZH_TW to Str(
        "計算器", "設置", "深色模式", "桌布", "震動", "語言", "關於",
        "跟隨系統", "桌布取色", "無", "關閉", "標準", "增強", "取消",
        "版本 V2.0-release", "確定", "更換桌布需要「允許存取所有檔案」權限", "去授權", "恢復預設", "關閉", "錯誤", "複製"
    ),
    Lang.EN to Str(
        "Calculator", "Settings", "Dark mode", "Wallpaper", "Vibration", "Language", "About",
        "Follow system", "Wallpaper color", "None", "Off", "Standard", "Enhanced", "Cancel",
        "Version V2.0-release", "OK", "Changing wallpaper requires 'All files access' permission", "Grant", "Restore default", "Close", "Error", "Copy"
    )
)

private fun stringsFor(lang: Lang): Str = strings[lang]!!

data class FeatureIntro(val title: String, val lines: List<String>, val continueLabel: String)

private fun featureIntroFor(lang: Lang): FeatureIntro = when (lang) {
    Lang.ZH_CN -> FeatureIntro(
        "功能介绍",
        listOf(
            "· 液态玻璃按键，按压有折射与形变动画",
            "· 支持多步算式编辑、可拖动光标定位输入",
            "· 顶栏记录最近 10 次计算，可展开查看、回填结果、双击清空",
            "· 深色/浅色主题可跟随系统或壁纸取色",
            "· 支持自定义壁纸（≤50MB）与三档震动反馈"
        ),
        "继续"
    )
    Lang.ZH_TW -> FeatureIntro(
        "功能介紹",
        listOf(
            "· 液態玻璃按鍵，按壓有折射與形變動畫",
            "· 支援多步算式編輯、可拖動游標定位輸入",
            "· 頂欄記錄最近 10 次計算，可展開查看、回填結果、雙擊清空",
            "· 深色/淺色主題可跟隨系統或桌布取色",
            "· 支援自訂桌布（≤50MB）與三檔震動回饋"
        ),
        "繼續"
    )
    Lang.EN -> FeatureIntro(
        "Features",
        listOf(
            "· Liquid-glass buttons with refraction and press deformation",
            "· Multi-step expression editing with a draggable cursor",
            "· Top bar keeps the last 10 calculations; expand to view, reuse results, double-tap to clear",
            "· Dark/light theme follows the system or samples the wallpaper",
            "· Custom wallpaper (≤50MB) and three-level haptic feedback"
        ),
        "Continue"
    )
}

data class HistoryItem(val expr: String, val result: String)

private fun serializeHistory(history: List<HistoryItem>): String =
    history.joinToString("|") { "${it.expr}=${it.result}" }

private fun deserializeHistory(s: String): List<HistoryItem> =
    s.split("|").filter { it.isNotEmpty() }.mapNotNull {
        val idx = it.indexOf('=')
        if (idx > 0) HistoryItem(it.substring(0, idx), it.substring(idx + 1)) else null
    }

private fun formatResult(v: Double): String {
    if (v.isNaN() || v.isInfinite()) return "错误"
    val bd = BigDecimal(v).setScale(10, RoundingMode.HALF_UP).stripTrailingZeros()
    return if (bd.signum() == 0) "0" else bd.toPlainString()
}

private sealed class Tok
private data class NumTok(val v: Double) : Tok()
private data class OpTok(val op: Char) : Tok()

private fun tokenize(s: String): List<Tok>? {
    val tokens = mutableListOf<Tok>()
    var i = 0
    while (i < s.length) {
        val c = s[i]
        when {
            c.isDigit() || c == '.' -> {
                val start = i
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                val num = s.substring(start, i).toDoubleOrNull() ?: return null
                tokens.add(NumTok(num))
            }
            c == '+' || c == '-' || c == '×' || c == '÷' -> {
                tokens.add(OpTok(c)); i++
            }
            else -> return null
        }
    }
    return tokens
}

private fun evaluateExpression(s: String): Double? {
    val tokens = tokenize(s) ?: return null
    if (tokens.isEmpty()) return null
    var i = 0
    fun parseFactor(): Double? {
        if (i >= tokens.size) return null
        val t = tokens[i]
        if (t is OpTok && (t.op == '-' || t.op == '+')) {
            i++
            val v = parseFactor() ?: return null
            return if (t.op == '-') -v else v
        }
        if (t is NumTok) { i++; return t.v }
        return null
    }
    fun parseTerm(): Double? {
        var v = parseFactor() ?: return null
        while (i < tokens.size && tokens[i] is OpTok) {
            val op = (tokens[i] as OpTok).op
            if (op != '×' && op != '÷') break
            i++
            val rhs = parseFactor() ?: return null
            if (op == '÷' && rhs == 0.0) return null
            v = if (op == '×') v * rhs else v / rhs
        }
        return v
    }
    fun parseExpr(): Double? {
        var v = parseTerm() ?: return null
        while (i < tokens.size && tokens[i] is OpTok) {
            val op = (tokens[i] as OpTok).op
            if (op != '+' && op != '-') break
            i++
            val rhs = parseTerm() ?: return null
            v = if (op == '+') v + rhs else v - rhs
        }
        return v
    }
    val result = parseExpr()
    return if (i == tokens.size) result else null
}

@Composable
fun CalculatorApp() {
    val backdrop = rememberLayerBackdrop()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("calc_prefs", 0) }

    var oobeDone by remember { mutableStateOf(prefs.getBoolean("oobe_done", false)) }
    var language by remember { mutableStateOf(prefs.getString("language", "en") ?: "en") }

    val defaultWallpaper = remember {
        try { BitmapFactory.decodeResource(context.resources, R.drawable.default_wallpaper) } catch (e: Exception) { null }
    }

    val scope = rememberCoroutineScope()
    val oobeExit = remember { Animatable(if (oobeDone) 0f else 1f) }
    val mainEnter = remember { Animatable(if (oobeDone) 1f else 0f) }

    if (!oobeDone) {
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                scaleX = oobeExit.value
                scaleY = oobeExit.value
                alpha = oobeExit.value
            }
        ) {
            OobeScreen(defaultWallpaper, onDone = { code ->
                language = code
                prefs.edit().putString("language", code).putBoolean("oobe_done", true).apply()
                scope.launch {
                    oobeExit.animateTo(0f, tween(350))
                    oobeDone = true
                    mainEnter.animateTo(1f, tween(500))
                }
            })
        }
        return
    }

    val lang = Lang.values().find { it.code == language } ?: Lang.EN
    val str = stringsFor(lang)

    var darkMode by remember { mutableStateOf(prefs.getString("dark_mode", "manual") ?: "manual") }
    var manualDark by remember { mutableStateOf(prefs.getBoolean("manual_dark", true)) }
    var wallpaperPath by remember { mutableStateOf(prefs.getString("wallpaper", null)) }
    val wallpaper = remember(wallpaperPath) { wallpaperPath?.let { decodeWallpaper(it) } }
    val effectiveWallpaper = wallpaper ?: defaultWallpaper

    val dark = when (darkMode) {
        "system" -> isSystemInDarkTheme()
        "wallpaper" -> effectiveWallpaper?.let { isWallpaperDark(it) } ?: manualDark
        else -> manualDark
    }
    val gradientColors = if (dark) DarkGradient else LightGradient
    val fg = if (dark) Color.White else Color(0xFF15151A)
    val buttonSurface = if (dark) Color(0xFF0D0D10).copy(alpha = 0.5f) else Color(0xFFFFFFFF).copy(alpha = 0.42f)
    val displayColor = if (dark) Color.White.copy(alpha = 0.6f) else Color(0xFF5A5A5A).copy(alpha = 0.9f)

    var showMenu by remember { mutableStateOf(false) }
    var showVibration by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showLanguage by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showPermDialog by remember { mutableStateOf(false) }
    var showWallpaperPicker by remember { mutableStateOf(false) }
    var currentDir by remember { mutableStateOf(File(Environment.getExternalStorageDirectory().path)) }

    var vibrationLevel by remember { mutableStateOf(prefs.getString("vibration_level", "standard") ?: "standard") }
    val haptic = LocalHapticFeedback.current

    var expr by remember { mutableStateOf(TextFieldValue("0", TextRange(1))) }
    val history = remember {
        mutableStateListOf<HistoryItem>().apply {
            addAll(deserializeHistory(prefs.getString("history", "") ?: ""))
        }
    }

    fun persistHistory() {
        prefs.edit().putString("history", serializeHistory(history.toList())).apply()
    }

    fun clearHistory() {
        history.clear()
        persistHistory()
    }

    fun insertAtCursor(s: String) {
        val tf = expr
        val start = minOf(tf.selection.start, tf.selection.end)
        val end = maxOf(tf.selection.start, tf.selection.end)
        val newText = tf.text.substring(0, start) + s + tf.text.substring(end)
        expr = TextFieldValue(newText, TextRange(start + s.length))
    }

    fun replaceText(s: String) {
        expr = TextFieldValue(s, TextRange(s.length))
    }

    fun useResult(result: String) {
        if (expr.text == "0" || expr.text == str.error) replaceText(result)
        else insertAtCursor(result)
    }

    fun onDigit(d: String) {
        if (expr.text == "0" || expr.text == str.error) replaceText(d)
        else insertAtCursor(d)
    }

    fun onDot() {
        if (expr.text == "0" || expr.text == str.error) replaceText("0.")
        else insertAtCursor(".")
    }

    fun onOperator(op: String) {
        when {
            expr.text == str.error -> replaceText("0" + op)
            expr.text == "0" && op == "-" -> replaceText("-")
            else -> insertAtCursor(op)
        }
    }

    fun onBackspace() {
        val tf = expr
        val start = minOf(tf.selection.start, tf.selection.end)
        val end = maxOf(tf.selection.start, tf.selection.end)
        val newText = if (start != end) {
            tf.text.substring(0, start) + tf.text.substring(end)
        } else if (start > 0) {
            tf.text.substring(0, start - 1) + tf.text.substring(start)
        } else {
            tf.text
        }
        val newCursor = if (start != end) start else (start - 1).coerceAtLeast(0)
        expr = TextFieldValue(newText.ifEmpty { "0" }, TextRange(newCursor))
    }

    fun onClear() {
        replaceText("0")
    }

    fun onEquals() {
        val text = expr.text
        val result = evaluateExpression(text)
        if (result != null) {
            val formatted = formatResult(result)
            history.add(0, HistoryItem(text, formatted))
            while (history.size > 10) history.removeAt(history.size - 1)
            persistHistory()
            replaceText(formatted)
        } else {
            replaceText(str.error)
        }
    }

    fun requestWallpaper() {
        if (Environment.isExternalStorageManager()) {
            currentDir = File(Environment.getExternalStorageDirectory().path)
            showWallpaperPicker = true
        } else {
            showPermDialog = true
        }
    }

    fun toggleThemeByLongPress() {
        if (darkMode == "manual") {
            manualDark = !manualDark
            prefs.edit().putBoolean("manual_dark", manualDark).apply()
            hapticType(vibrationLevel, true)?.let { haptic.performHapticFeedback(it) }
        }
    }

    CompositionLocalProvider(LocalVibrationLevel provides vibrationLevel) {
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            scaleX = mainEnter.value
            scaleY = mainEnter.value
            alpha = mainEnter.value
            translationY = (1f - mainEnter.value) * 60.dp.toPx()
        }
    ) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
            if (effectiveWallpaper != null) {
                Image(
                    bitmap = effectiveWallpaper.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(gradientColors)))
            }
        }

        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 16.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicText(
                    str.title,
                    style = TextStyle(color = fg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                )
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    HistoryPill(history, fg, dark, str.copy, ::clearHistory, onUseResult = { useResult(it) })
                }
                Box(Modifier.size(44.dp).clickable { showMenu = true }, contentAlignment = Alignment.Center) {
                    BasicText("⋮", style = TextStyle(color = fg, fontSize = 24.sp))
                }
            }

            Box(
                Modifier.fillMaxWidth().weight(1f).padding(end = 8.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                BasicTextField(
                    value = expr,
                    onValueChange = { expr = it },
                    readOnly = true,
                    singleLine = true,
                    textStyle = TextStyle(
                        color = displayColor,
                        fontSize = when { expr.text.length > 10 -> 40.sp; expr.text.length > 7 -> 48.sp; else -> 60.sp },
                        fontWeight = FontWeight.Light
                    ),
                    cursorBrush = SolidColor(fg),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Row {
                GlassButton("AC", backdrop, Modifier.weight(2f).aspectRatio(2f), ::onClear, null, buttonSurface, fg, strongHaptic = true)
                GlassButton("÷", backdrop, Modifier.weight(1f).aspectRatio(1f), { onOperator("÷") }, null, buttonSurface, fg)
                GlassButton("×", backdrop, Modifier.weight(1f).aspectRatio(1f), { onOperator("×") }, null, buttonSurface, fg)
            }
            Row {
                GlassButton("7", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("7") }, null, buttonSurface, fg)
                GlassButton("8", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("8") }, null, buttonSurface, fg)
                GlassButton("9", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("9") }, null, buttonSurface, fg)
                GlassButton("-", backdrop, Modifier.weight(1f).aspectRatio(1f), { onOperator("-") }, null, buttonSurface, fg)
            }
            Row {
                GlassButton("4", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("4") }, null, buttonSurface, fg)
                GlassButton("5", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("5") }, null, buttonSurface, fg)
                GlassButton("6", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("6") }, null, buttonSurface, fg)
                GlassButton("+", backdrop, Modifier.weight(1f).aspectRatio(1f), { onOperator("+") }, null, buttonSurface, fg)
            }
            Row {
                Column(Modifier.weight(3f)) {
                    Row {
                        GlassButton("1", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("1") }, null, buttonSurface, fg)
                        GlassButton("2", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("2") }, null, buttonSurface, fg)
                        GlassButton("3", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("3") }, null, buttonSurface, fg)
                    }
                    Row {
                        GlassButton("0", backdrop, Modifier.weight(1f).aspectRatio(1f), { onDigit("0") }, null, buttonSurface, fg)
                        GlassButton(".", backdrop, Modifier.weight(1f).aspectRatio(1f), ::onDot, null, buttonSurface, fg)
                        GlassButton("⌫", backdrop, Modifier.weight(1f).aspectRatio(1f), ::onBackspace, null, buttonSurface, fg)
                    }
                }
                GlassButton("=", backdrop, Modifier.weight(1f).aspectRatio(0.5f), ::onEquals, ::toggleThemeByLongPress, buttonSurface, fg, strongHaptic = true)
            }
        }
    }

    if (showMenu) {
        Dialog(onDismissRequest = { showMenu = false }) {
            DialogPanel {
                BasicText(str.settings, style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold), modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
                DialogItem(str.darkMode) { showMenu = false; showSettings = true }
                DialogItem(str.wallpaper) { showMenu = false; requestWallpaper() }
                DialogItem(str.vibration) { showMenu = false; showVibration = true }
                DialogItem(str.language) { showMenu = false; showLanguage = true }
                DialogItem(str.about) { showMenu = false; showAbout = true }
            }
        }
    }
    if (showVibration) {
        Dialog(onDismissRequest = { showVibration = false }) {
            DialogPanel {
                BasicText(str.vibration, style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold), modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
                DialogItem(str.off + if (vibrationLevel == "off") "  ✓" else "") {
                    vibrationLevel = "off"
                    prefs.edit().putString("vibration_level", "off").apply()
                    showVibration = false
                }
                DialogItem(str.standard + if (vibrationLevel == "standard") "  ✓" else "") {
                    vibrationLevel = "standard"
                    prefs.edit().putString("vibration_level", "standard").apply()
                    showVibration = false
                }
                DialogItem(str.enhanced + if (vibrationLevel == "enhanced") "  ✓" else "") {
                    vibrationLevel = "enhanced"
                    prefs.edit().putString("vibration_level", "enhanced").apply()
                    showVibration = false
                }
                DialogItem(str.cancel, isCancel = true) { showVibration = false }
            }
        }
    }
    if (showLanguage) {
        Dialog(onDismissRequest = { showLanguage = false }) {
            DialogPanel {
                BasicText(str.language, style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold), modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
                DialogItem("简体中文" + if (language == "zh-CN") "  ✓" else "") {
                    language = "zh-CN"
                    prefs.edit().putString("language", "zh-CN").apply()
                    showLanguage = false
                }
                DialogItem("繁體中文" + if (language == "zh-TW") "  ✓" else "") {
                    language = "zh-TW"
                    prefs.edit().putString("language", "zh-TW").apply()
                    showLanguage = false
                }
                DialogItem("English" + if (language == "en") "  ✓" else "") {
                    language = "en"
                    prefs.edit().putString("language", "en").apply()
                    showLanguage = false
                }
                DialogItem(str.cancel, isCancel = true) { showLanguage = false }
            }
        }
    }
    if (showSettings) {
        Dialog(onDismissRequest = { showSettings = false }) {
            DialogPanel {
                BasicText(str.darkMode, style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold), modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
                DialogItem(str.followSystem + if (darkMode == "system") "  ✓" else "") {
                    darkMode = "system"
                    prefs.edit().putString("dark_mode", "system").apply()
                    showSettings = false
                }
                DialogItem(str.wallpaperColor + if (darkMode == "wallpaper") "  ✓" else "") {
                    darkMode = "wallpaper"
                    prefs.edit().putString("dark_mode", "wallpaper").apply()
                    showSettings = false
                }
                DialogItem(str.none + if (darkMode == "manual") "  ✓" else "") {
                    darkMode = "manual"
                    prefs.edit().putString("dark_mode", "manual").apply()
                    showSettings = false
                }
                DialogItem(str.cancel, isCancel = true) { showSettings = false }
            }
        }
    }
    if (showAbout) {
        Dialog(onDismissRequest = { showAbout = false }) {
            DialogPanel {
                BasicText(str.version, style = TextStyle(color = Color.White, fontSize = 20.sp), modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
                DialogItem(str.ok, isCancel = true) { showAbout = false }
            }
        }
    }
    if (showPermDialog) {
        Dialog(onDismissRequest = { showPermDialog = false }) {
            DialogPanel {
                BasicText(str.permText, style = TextStyle(color = Color.White, fontSize = 16.sp), modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
                DialogItem(str.grant) {
                    showPermDialog = false
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
                    context.startActivity(intent)
                }
                DialogItem(str.cancel, isCancel = true) { showPermDialog = false }
            }
        }
    }
    if (showWallpaperPicker) {
        WallpaperPicker(
            str = str,
            currentDir = currentDir,
            onDirChange = { currentDir = it },
            onPick = { path ->
                wallpaperPath = path
                prefs.edit().putString("wallpaper", path).apply()
                showWallpaperPicker = false
            },
            onReset = {
                wallpaperPath = null
                prefs.edit().remove("wallpaper").apply()
                showWallpaperPicker = false
            },
            onClose = { showWallpaperPicker = false }
        )
    }
    }
}

@Composable
private fun OobeScreen(wallpaper: Bitmap?, onDone: (String) -> Unit) {
    var selected by remember { mutableStateOf("en") }
    var showIntro by remember { mutableStateOf(false) }
    val backdrop = rememberLayerBackdrop()

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
            if (wallpaper != null) {
                Image(
                    bitmap = wallpaper.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF16324F), Color(0xFF0A4D8C), Color(0xFF3A2E6E), Color(0xFF16324F)))))
            }
        }

        if (!showIntro) {
            Column(
                Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                BasicText(
                    "选择语言 / Select language",
                    style = TextStyle(color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                )
                Box(Modifier.height(24.dp))
                OobeOption(backdrop, "简体中文", selected == "zh-CN") { selected = "zh-CN" }
                OobeOption(backdrop, "繁體中文", selected == "zh-TW") { selected = "zh-TW" }
                OobeOption(backdrop, "English", selected == "en") { selected = "en" }
                Box(Modifier.height(32.dp))
                OobeConfirmButton(backdrop, "开始 / Start", onClick = { showIntro = true })
            }
        } else {
            val intro = featureIntroFor(Lang.values().find { it.code == selected } ?: Lang.EN)
            Column(
                Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 32.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                BasicText(
                    intro.title,
                    style = TextStyle(color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                )
                Box(Modifier.height(20.dp))
                intro.lines.forEach { line ->
                    BasicText(
                        line,
                        style = TextStyle(color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    )
                }
                Box(Modifier.height(28.dp))
                OobeConfirmButton(backdrop, intro.continueLabel, onClick = { onDone(selected) })
            }
        }
    }
}

@Composable
private fun OobeOption(backdrop: Backdrop, text: String, selected: Boolean, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val vibrationLevel = LocalVibrationLevel.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val press by animateFloatAsState(
        targetValue = if (isPressed) 1f else 0f,
        animationSpec = spring(stiffness = 500f, dampingRatio = 0.7f)
    )

    Box(
        Modifier.fillMaxWidth().padding(vertical = 6.dp)
            .drawBackdrop(
                backdrop = backdrop,
                shape = { RoundedCornerShape(16.dp) },
                effects = {
                    vibrancy()
                    blur(2f.dp.toPx())
                    lens(14f.dp.toPx(), 22f.dp.toPx())
                },
                layerBlock = {
                    val s = 1f + 0.08f * press
                    scaleX = s
                    scaleY = s
                },
                onDrawSurface = {
                    drawRect(if (selected) Color(0xFF0A84FF).copy(alpha = 0.55f) else Color.White.copy(alpha = 0.06f))
                }
            )
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    hapticType(vibrationLevel, false)?.let { haptic.performHapticFeedback(it) }
                    onClick()
                }
            )
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        BasicText(
            text + if (selected) "  ✓" else "",
            style = TextStyle(color = Color.White, fontSize = 17.sp)
        )
    }
}

@Composable
private fun OobeConfirmButton(backdrop: Backdrop, text: String, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val vibrationLevel = LocalVibrationLevel.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val press by animateFloatAsState(
        targetValue = if (isPressed) 1f else 0f,
        animationSpec = spring(stiffness = 500f, dampingRatio = 0.7f)
    )

    Box(
        Modifier.fillMaxWidth().padding(vertical = 6.dp)
            .drawBackdrop(
                backdrop = backdrop,
                shape = { RoundedCornerShape(24.dp) },
                effects = {
                    vibrancy()
                    blur(2f.dp.toPx())
                    lens(14f.dp.toPx(), 22f.dp.toPx())
                },
                layerBlock = {
                    val s = 1f + 0.08f * press
                    scaleX = s
                    scaleY = s
                },
                onDrawSurface = {
                    drawRect(Color(0xFF0A84FF).copy(alpha = 0.5f))
                }
            )
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    hapticType(vibrationLevel, false)?.let { haptic.performHapticFeedback(it) }
                    onClick()
                }
            )
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        BasicText(text, style = TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold))
    }
}

@Composable
private fun HistoryPill(history: List<HistoryItem>, fg: Color, dark: Boolean, copyLabel: String, onClear: () -> Unit, onUseResult: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val widthFraction by animateFloatAsState(
        targetValue = if (expanded) 0.92f else 0.5f,
        animationSpec = spring(stiffness = 300f, dampingRatio = 0.8f)
    )

    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxWidth(widthFraction).height(36.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = 0.18f))
                .combinedClickable(
                    onClick = { expanded = !expanded },
                    onDoubleClick = { onClear() }
                ),
            contentAlignment = Alignment.Center
        ) {
            val last = history.firstOrNull()
            BasicText(
                if (last != null) "${last.expr} = ${last.result}" else "",
                style = TextStyle(color = fg, fontSize = 13.sp),
                maxLines = 1
            )
        }
    }

    if (expanded) {
        Dialog(onDismissRequest = { expanded = false }) {
            val panelBg = if (dark) Color(0xFF1A1A1E).copy(alpha = 0.6f) else Color(0xFFFFFFFF).copy(alpha = 0.6f)
            val panelText = if (dark) Color.White else Color(0xFF1A1A1A)
            Column(
                Modifier.fillMaxWidth().background(panelBg, RoundedCornerShape(20.dp)).padding(20.dp)
            ) {
                if (history.isEmpty()) {
                    BasicText("", style = TextStyle(color = panelText, fontSize = 15.sp))
                } else {
                    history.forEach { item ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            BasicText(
                                "${item.expr} = ${item.result}",
                                style = TextStyle(color = panelText, fontSize = 15.sp),
                                modifier = Modifier.weight(1f)
                            )
                            Box(
                                Modifier.clickable {
                                    onUseResult(item.result)
                                    expanded = false
                                }.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                BasicText(copyLabel, style = TextStyle(color = Color(0xFF0A84FF), fontSize = 13.sp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WallpaperPicker(
    str: Str,
    currentDir: File,
    onDirChange: (File) -> Unit,
    onPick: (String) -> Unit,
    onReset: () -> Unit,
    onClose: () -> Unit
) {
    val rootPath = remember { Environment.getExternalStorageDirectory().path }
    val context = LocalContext.current
    val files = remember(currentDir) {
        currentDir.listFiles()?.toList()?.sortedWith(
            compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() }
        ) ?: emptyList()
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF151517)).safeDrawingPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(44.dp).clickable {
                        val parent = currentDir.parentFile
                        if (parent != null && currentDir.path != rootPath) onDirChange(parent) else onClose()
                    },
                    contentAlignment = Alignment.Center
                ) {
                    BasicText("←", style = TextStyle(color = Color.White, fontSize = 22.sp))
                }
                BasicText(
                    currentDir.path,
                    style = TextStyle(color = Color(0xFFAAAAAA), fontSize = 13.sp),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Box(Modifier.clickable { onReset() }.padding(8.dp)) {
                    BasicText(str.restoreDefault, style = TextStyle(color = Color(0xFF4DA3FF), fontSize = 14.sp))
                }
                Box(Modifier.clickable { onClose() }.padding(8.dp)) {
                    BasicText(str.close, style = TextStyle(color = Color(0xFF4DA3FF), fontSize = 14.sp))
                }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                files.forEach { file ->
                    if (file.isDirectory || isImage(file)) {
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (file.isDirectory) onDirChange(file)
                                else if (file.length() <= 50L * 1024 * 1024) onPick(file.absolutePath)
                                else Toast.makeText(context, "壁纸文件需 ≤ 50MB", Toast.LENGTH_SHORT).show()
                            }.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BasicText(
                                (if (file.isDirectory) "📁 " else "🖼 ") + file.name,
                                style = TextStyle(color = Color.White, fontSize = 15.sp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DialogPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF26262A), RoundedCornerShape(22.dp)).padding(vertical = 8.dp),
        content = content
    )
}

@Composable
private fun DialogItem(text: String, isCancel: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        BasicText(
            text,
            style = TextStyle(color = if (isCancel) Color(0xFF4DA3FF) else Color.White, fontSize = 16.sp)
        )
    }
}

@Composable
fun GlassButton(
    text: String,
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    surfaceColor: Color = Color.White.copy(alpha = 0.05f),
    textColor: Color = Color.White,
    strongHaptic: Boolean = false
) {
    val haptic = LocalHapticFeedback.current
    val vibrationLevel = LocalVibrationLevel.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val press by animateFloatAsState(
        targetValue = if (isPressed) 1f else 0f,
        animationSpec = spring(stiffness = 500f, dampingRatio = 0.7f)
    )

    Box(
        modifier
            .padding(6.dp)
            .drawBackdrop(
                backdrop = backdrop,
                shape = { RoundedCornerShape(16.dp) },
                effects = {
                    vibrancy()
                    blur(2f.dp.toPx())
                    lens(18f.dp.toPx(), 30f.dp.toPx())
                },
                layerBlock = {
                    val s = 1f + 0.08f * press
                    scaleX = s
                    scaleY = s
                },
                onDrawSurface = {
                    drawRect(surfaceColor)
                }
            )
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    hapticType(vibrationLevel, strongHaptic)?.let { haptic.performHapticFeedback(it) }
                    onClick()
                },
                onLongClick = onLongClick
            ),
        contentAlignment = Alignment.Center
    ) {
        BasicText(
            text,
            style = TextStyle(
                color = textColor,
                fontSize = if (text in listOf("÷", "×", "-", "+", "=")) 26.sp else 22.sp,
                fontWeight = if (text in listOf("÷", "×", "-", "+", "=")) FontWeight.Bold else FontWeight.Normal
            )
        )
    }
}
